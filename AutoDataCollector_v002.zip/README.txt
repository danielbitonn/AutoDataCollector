v001: 07/12/2023
.bat automation

v002: 10/12/2023
schedule automation (even if the computer is off on time)